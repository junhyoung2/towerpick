
const StartPage = () => {
    return (
        <div className="start-page">
            <h1>모바일 시작페이지</h1>
        </div>
    );
};

export default StartPage;