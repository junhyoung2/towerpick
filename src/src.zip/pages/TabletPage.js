const TabletPage = () => {
    return (
        <div id="tablet-page">
            <h1>테블릿 시작 페이지</h1>
        </div>
    );
};

export default TabletPage;
